package triana.salesianos.dam.JoinedInheritance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoinedInheritanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(JoinedInheritanceApplication.class, args);
	}

}
